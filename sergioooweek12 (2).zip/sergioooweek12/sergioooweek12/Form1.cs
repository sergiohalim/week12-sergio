﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Reflection.Emit;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace sergioooweek12
{
    public partial class Form1 : Form
    {
        MySqlConnection MySqlConnection;
        MySqlCommand Command;
        MySqlDataAdapter DataAdapter;
        MySqlDataReader Reader;
        DataTable Player = new DataTable();
        DataTable Nationality = new DataTable();
        DataTable Team = new DataTable();
        DataTable manager1 = new DataTable();
        DataTable Managermager = new DataTable();
        DataTable Dataplayer = new DataTable();
        DataTable manager2 = new DataTable();
        DataTable IDManager = new DataTable();
        DataTable remove = new DataTable();
        string managername = "";
        string deleteplayer = "";
        public Form1()
        {

            try
            {
                string connection = "server=localhost;uid=root;pwd=;database=premier_league";
                MySqlConnection = new MySqlConnection(connection);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            InitializeComponent();
        }
        private void updateplayer()
        {
            Player.Clear();
            try
            {
                string playerdata = "select*from player";
                Command = new MySqlCommand(playerdata, MySqlConnection);
                DataAdapter = new MySqlDataAdapter(Command);
                DataAdapter.Fill(Player);
                dataGridView1.DataSource = (Player);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string query = "select nationality_id,nation from nationality;";
            Command = new MySqlCommand(query, MySqlConnection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(Nationality);
            comnationality.DataSource = Nationality;
            comnationality.ValueMember = "nationality_id";
            comnationality.DisplayMember = "nation";

            string hello = "select team_id,team_name from team;";
            Command = new MySqlCommand(hello, MySqlConnection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(Team);
            comteamname.DataSource = Team;
            comteamname.ValueMember = "team_id";
            comteamname.DisplayMember = "team_name";
            string hello1 = "select team_id,team_name from team;";

            Command = new MySqlCommand(hello1, MySqlConnection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(manager2);
            comboteam.DataSource = manager2;
            comboteam.ValueMember = "team_id";
            comboteam.DisplayMember = "team_name";

            string managermager = "select m.manager_name,m.birthdate,n.nation from manager m,nationality n where m.working=0 and m.nationality_id=n.nationality_id;";
            Command = new MySqlCommand(managermager, MySqlConnection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(Managermager);
            dataGridView2.DataSource = Managermager;

            string hello2 = "select team_id,team_name from team;";
            Command = new MySqlCommand(hello2, MySqlConnection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(remove);
            comboBox1.DataSource = remove;
            comboBox1.ValueMember = "team_id";
            comboBox1.DisplayMember = "team_name";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {

            string playerID = textpalyerid.Text;
            string playerName = textname.Text;
            string teamNumber = textteamnumber.Text;
            string nationalityID = comnationality.SelectedValue.ToString();
            string playingPos = textposition.Text;
            string Height = textheight.Text;
            string Weight = textweight.Text;
            string Birthdate = dateTimebirthdate.Value.ToString("yyyy-MM-dd");
            string Teamname = comteamname.SelectedValue.ToString();
            string Player = $"insert into player values('{playerID}','{teamNumber}','{playerName}','{nationalityID}','{playingPos}','{Height}','{Weight}','{Birthdate}','{Teamname}',1,0)";
            try
            {
                MySqlConnection.Open();
                Command = new MySqlCommand(Player, MySqlConnection);
                Reader = Command.ExecuteReader();
            }
            catch (Exception f)
            {
                MessageBox.Show(f.Message);
            }
            finally
            {
                MySqlConnection.Close();
                updateplayer();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string playerID = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            label10.Text = playerID;
        }

        private void comboteam_SelectedIndexChanged(object sender, EventArgs e)
        {
            manager1.Clear();
            string manager = $" select m.manager_name,t.team_name,m.birthdate,n.nation from manager m,team t,nationality n where m.manager_id=t.manager_id and n.nationality_id=m.nationality_id and t.team_id='{comboteam.SelectedValue.ToString()}';";
            Command = new MySqlCommand(manager, MySqlConnection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(manager1);
            dataGridView3.DataSource = manager1;
        }
        private void comboteam_SelectionChangeCommitted(object sender, EventArgs e)
        {
           
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            managername = dataGridView2.CurrentCell.Value.ToString();
            label13.Text = managername;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            IDManager.Clear();
            string updatemanager = manager1.Rows[0][0].ToString();
            string managerid = $"select manager_id from manager where manager_name='{managername}';";
            Command = new MySqlCommand(managerid, MySqlConnection);
            DataAdapter = new MySqlDataAdapter(Command);
            DataAdapter.Fill(IDManager);
            string id = IDManager.Rows[0][0].ToString();

            string update = $"UPDATE team t,manager mkanan,manager mkiri set t.manager_id='{id}',mkiri.working=1,mkanan.working=0 where mkanan.manager_name='{updatemanager}' AND mkiri.manager_id='{id}' AND t.team_id='{comboteam.SelectedValue.ToString()}';";
            try
            {
                MySqlConnection.Open();
                Command = new MySqlCommand(update, MySqlConnection);
                Reader = Command.ExecuteReader();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                MySqlConnection.Close();
                manager1.Clear();
                Managermager.Clear();
                string manager = $" select m.manager_name,t.team_name,m.birthdate,n.nation from manager m,team t,nationality n where m.manager_id=t.manager_id and n.nationality_id=m.nationality_id and t.team_id='{comboteam.SelectedValue.ToString()}';";
                Command = new MySqlCommand(manager, MySqlConnection);
                DataAdapter = new MySqlDataAdapter(Command);
                DataAdapter.Fill(manager1);
                dataGridView3.DataSource = manager1;
                string managermager = "select m.manager_name,m.birthdate,n.nation from manager m,nationality n where m.working=0 and m.nationality_id=n.nationality_id;";
                Command = new MySqlCommand(managermager, MySqlConnection);
                DataAdapter = new MySqlDataAdapter(Command);
                DataAdapter.Fill(Managermager);
                dataGridView2.DataSource = Managermager;
                managername = "";
            }
        }

        private void dataGridView4_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }
        private void button3_Click(object sender, EventArgs e)
        {
            int count = 0;
            for (int i = 0; i < Dataplayer.Rows.Count; i++)
            {
                count++;
            }
            if (count <= 11)
            {
                MessageBox.Show("error", "cannot remove player", MessageBoxButtons.OK);
            }
            else
            {
                string deletepemain = $"UPDATE player set status=0 WHERE player_name='{deleteplayer}';";

                try
                {
                    MySqlConnection.Open();
                    Command = new MySqlCommand(deletepemain, MySqlConnection);
                    Reader = Command.ExecuteReader();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    Dataplayer.Clear();
                    MySqlConnection.Close();
                    string chooseteam = $"select p.player_name,n.nation,p.playing_pos,p.team_number,p.height,p.weight,p.birthdate from player p, team t,nationality n where p.team_id = t.team_id and p.status = 1 and t.team_id = '{comboBox1.SelectedValue.ToString()}' and n.nationality_id=p.nationality_id;";
                    Command = new MySqlCommand(chooseteam, MySqlConnection);
                    DataAdapter = new MySqlDataAdapter(Command);
                    DataAdapter.Fill(Dataplayer);
                    dataGridView5.DataSource = Dataplayer;
                }
            }
            deleteplayer = "";

         
        }
        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
      
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            Dataplayer.Clear();
            try
            {
                string chooseteam = $"select p.player_name,n.nation,p.playing_pos,p.team_number,p.height,p.weight,p.birthdate from player p, team t,nationality n where p.team_id = t.team_id and p.status = 1 and t.team_id = '{comboBox1.SelectedValue.ToString()}' and n.nationality_id=p.nationality_id;";
                Command = new MySqlCommand(chooseteam, MySqlConnection);
                DataAdapter = new MySqlDataAdapter(Command);
                DataAdapter.Fill(Dataplayer);
                dataGridView4.DataSource = Dataplayer;
            }
            catch (Exception f)
            {
                MessageBox.Show(f.Message);
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            deleteplayer = dataGridView5.CurrentCell.Value.ToString();
        }

        private void addPlayerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Show();
            panel1.Visible = true;
        }

        private void addManagerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Show();
            panel2.Visible = true;  
        }

        private void removeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel3.Show();
            panel3.Visible = true; 
        }
    }
    }
